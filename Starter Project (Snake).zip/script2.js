document.getElementById('botonps5').addEventListener('click', mostr);
function mostr() {
   window.location.href='disney.html' ;
}
